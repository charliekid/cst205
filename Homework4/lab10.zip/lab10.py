# CST 205
# Charlie Nguyen
# 11/2/20

from flask import Flask, render_template
from flask_bootstrap import Bootstrap

# Creates an instance of the Flask class
app = Flask(__name__)

bootstrap = Bootstrap(app)

@app.route('/hello')
def hello():
    my_string = "<p>Here are interesting facts...</p><br>Samuel - is taking 205 for fun to be a full time student <br> Justin - has a 9 year old cat<br>Michael- has 2 white poodles <br>alicia - is an only child "
    return my_string

# Home route
@app.route('/')
def home():
    my_string = "<H1>Welcome to my page!!!!</h1><p>My name is Charlie and I love to eat hotpot!</p>"
    return my_string

# Runs by template
@app.route('/charlie')
def t_test():
    return render_template('template.html')